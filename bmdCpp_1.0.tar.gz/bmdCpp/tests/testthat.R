library(testthat)
library(bmdCpp)

test_check("bmdCpp")
